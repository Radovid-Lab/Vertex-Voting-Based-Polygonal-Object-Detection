import math

def dotproduct(v1, v2):
    return sum((a*b) for a, b in zip(v1, v2))

def length(v):
    return math.sqrt(dotproduct(v, v))

def subtract(v1,v2):
    return [v1[0]-v2[0],v1[1]-v2[1]]

def angle_radian(v1,v2):
    eps=1/float('inf')
    return math.acos(dotproduct(v1,v2)/(length(v1)*length(v2)+eps))