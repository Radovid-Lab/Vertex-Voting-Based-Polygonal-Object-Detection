from task.visualize import poolingNMS,getPredictedCenter
import numpy as np
from sklearn.cluster import DBSCAN
from collections import defaultdict
from functools import reduce

def DBSC(data,epsilon = 20,minimumSamples = 3):
    '''
    apply DBSCAN on dataset
    :param data: predicted object centers
    :param epsilon: DBSCAN parameter
    :param minimumSamples: DBSCAN parameter
    :return: clustered points in dictionay form
    '''
    cluster = DBSCAN(eps=epsilon, min_samples=minimumSamples).fit(data)
    labels = cluster.labels_
    # remove outliers
    core_samples_mask = np.zeros_like(cluster.labels_, dtype=bool)
    core_samples_mask[cluster.core_sample_indices_] = True
    n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
    n_noise_ = list(labels).count(-1)
    print(f'number of clusters {n_clusters_}, number of noise {n_noise_}')
    dict=defaultdict(lambda :'None')
    for i in range(len(labels)):
        if core_samples_mask[i]==True:
            if dict[labels[i]]=='None':
                dict[labels[i]]=[data[i]]
            else:
                dict[labels[i]].append(data[i])
    return dict

def grouping(test_result):
    '''
    group corners based on their predicted object center.
    Corners with geometrically close centers will be attributed to the same object.
    :param test_result: dictionary type {'location': location, 'xvector': xvector, 'yvector': yvector}
    :return: grouped corners in dictionary form
    '''
    location = test_result['location'].detach()
    xoffset = test_result['xvector'].squeeze().detach()
    yoffset = test_result['yvector'].squeeze().detach()
    dict={}

    location_indices=[i.numpy() for i in poolingNMS(location)]
    for i in location_indices:
        predictedCenter=getPredictedCenter(i,xoffset,yoffset)
        predictedCenter=[np.round(j.numpy()) for j in predictedCenter]
        predictedCenter=tuple(predictedCenter)
        dict[predictedCenter]=i

    data=np.array(list(dict.keys()))
    clustered=DBSC(data)
    count=0
    for i in clustered.values():
        count+=len(i)
    result={}
    for i in clustered.keys():
        temp_cluster=clustered[i]
        temp_cornerlist=[]
        for j in temp_cluster:
            temp_cornerlist.append(dict[tuple(j)])
        result[i]=temp_cornerlist
    for i in result.keys():
        result[i]=graham([i.tolist() for i in result[i]])
    return result


def graham(points):
    '''
    Returns points on convex hull in CCW order according to Graham's scan algorithm.
    By Tom Switzer <thomas.switzer@gmail.com>.
    '''
    TURN_LEFT, TURN_RIGHT, TURN_NONE = (1, -1, 0)

    def cmp(a, b):
        return (a > b) - (a < b)

    def turn(p, q, r):
        return cmp((q[0] - p[0])*(r[1] - p[1]) - (r[0] - p[0])*(q[1] - p[1]), 0)

    def _keep_left(hull, r):
        while len(hull) > 1 and turn(hull[-2], hull[-1], r) == TURN_RIGHT:
            hull.pop()
        if not len(hull) or hull[-1] != r:
            hull.append(r)
        return hull

    points = sorted(points)
    l = reduce(_keep_left, points, [])
    u = reduce(_keep_left, reversed(points), [])
    return l.extend(u[i] for i in range(1, len(u) - 1)) or l