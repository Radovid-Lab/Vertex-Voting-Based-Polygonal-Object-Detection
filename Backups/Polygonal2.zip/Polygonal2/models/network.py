from torch import nn
from models.layers import *
from models.loss import HeatmapLossSL1,FocalLoss,HeatmapLossMSE
from conf.config import Config
import torch


class PolyNet(nn.Module):
    def __init__(self, config: Config):
        super(PolyNet, self).__init__()
        self.config = config
        self.pre = Hourglass(5, 3, increase=10)# downsample 5 times
        self.focalLoss=FocalLoss()
        # self.heatmapLoss = HeatmapLossMSE(weight=100, config=self.config)
        self.heatmapLoss = HeatmapLossSL1()
        # self.criterion = nn.BCELoss()  # standard BCEloss
        self.location = nn.Sequential(
            nn.Conv2d(3, 8, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(8, 16, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(16, 1, kernel_size=3, stride=1, padding=1),
        )

        self.xyoffsets =nn.Sequential( #2 channels for x and y
            nn.Conv2d(3, 8, kernel_size=3, stride=1, padding=1),
            nn.Tanh(),
            nn.Conv2d(8, 16, kernel_size=3, stride=1, padding=1),
            nn.Tanh(),
            nn.Conv2d(16, 2, kernel_size=3, stride=1, padding=1),
        )
        # self.conv=Conv(inp_dim=3, out_dim=1, kernel_size=1, stride=1, bn=False, relu=False)

    def forward(self, img):
        x = self.pre(img)
        location = self.location(x)
        # location=torch.sigmoid(self.conv(location))
        location = torch.sigmoid(location)
        xyoffset=self.xyoffsets(x)
        xoffset,yoffset=torch.split(xyoffset, 1, dim=1)
        return {"location": location, "xvector": xoffset, "yvector": yoffset}

    def cal_loss(self, predict, label, mean=True, alpha=100):
        '''
        calculate the loss. location uses BCE loss while offsets use heatmap(mse) loss.
        :param predict: predicted result
        :param label: ground truth
        :param mean: represents whether to average loss among all pixels
        :param alpha: control the contribution of first branch. total loss=alpha*loss1+loss2+loss3
        :return: loss
        '''
        # loss1 = self.criterion(predict['location'], label['location'])
        loss1=self.focalLoss(predict['location'],label['location'],mean=mean)
        loss2=self.heatmapLoss(predict["xvector"],label["xvector"],mean=mean)
        loss3=self.heatmapLoss(predict["yvector"],label["yvector"],mean=mean)
        return alpha*loss1+loss2+loss3