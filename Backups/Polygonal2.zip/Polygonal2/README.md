1.split data(will automatically put test data into map/imput/images-optional for future evaluation use)
2.train
3.test(will write result into map/input for evaluation use)